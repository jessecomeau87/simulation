---
name: Feature request
about: Suggest an idea for clangd
title: ''
labels: enhancement
assignees: ''

---


